using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyVersion("15.0.1.0")]
[assembly: AssemblyFileVersion("15.0.1.0")]
[assembly: AssemblyTitleAttribute("MS-WOPI_Adapter")]
[assembly: AssemblyProductAttribute("SharePoint File Sync and WOPI Protocol Test Suites")]